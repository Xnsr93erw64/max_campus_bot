from .storage import UserStorage, TaskStorage, FocusStorage

user_storage = UserStorage()
task_storage = TaskStorage()
focus_storage = FocusStorage()
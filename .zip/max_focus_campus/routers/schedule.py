from aiomax import Router
from aiomax.types import Message
from aiomax import buttons

from database import user_storage

schedule_router = Router()

@schedule_router.on_command("schedule")
async def show_schedule(message: Message):
    user = user_storage.get_user(message.sender.user_id)
    if not user or not user.onboarding_completed:
        await message.reply("⚠️ Сначала завершите настройку профиля командой /start")
        return
    
    await message.reply(
        "📚 **Ваше расписание**\n\n"
        f"• 🎓 Вуз: {user.university}\n"
        f"• 👥 Группа: {user.group}\n"
        f"• 🏷️ Предметы: {', '.join(user.tags) if user.tags else 'Не указаны'}\n"
        f"• 📅 Календарь: {'Подключен ✅' if user.calendar_url else 'Не подключен ❌'}\n\n"
        "Используйте команды:\n"
        "• /deadlines - показать дедлайны\n"
        "• /focus - начать фокус-сессию\n"
        "• /stats - статистика продуктивности",
        keyboard=buttons.KeyboardBuilder()
        .add(buttons.MessageButton("📅 Мои дедлайны"))
        .row(buttons.MessageButton("🎯 Начать фокус"), buttons.MessageButton("📊 Статистика"))
    )
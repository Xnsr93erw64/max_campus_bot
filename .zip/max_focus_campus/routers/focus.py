from aiomax import Router
from aiomax.types import Message
from aiomax.fsm import FSMCursor
from aiomax import buttons
from aiomax.filters import has
import asyncio
from datetime import datetime, timedelta

from database import user_storage, focus_storage
from database.models import FocusSession, TaskStatus

focus_router = Router()


class FocusState:
    WORKING = "focus_working"
    BREAK = "focus_break"
    LONG_BREAK = "focus_long_break"


@focus_router.on_command("focus")
async def start_focus(message: Message, cursor: FSMCursor):
    user = user_storage.get_user(message.sender.user_id)
    if not user or not user.onboarding_completed:
        await message.reply("⚠️ Сначала завершите настройку профиля командой /start")
        return

    await message.reply(
        "🎯 **Фокус-сессия Pomodoro**\n\n"
        "Выберите продолжительность:\n"
        "• 🍅 25 минут (стандартный Pomodoro)\n"
        "• 🔥 50 минут (глубокая работа)\n"
        "• ⚡ 15 минут (быстрая задача)",
        keyboard=buttons.KeyboardBuilder()
        .add(buttons.MessageButton("🍅 25 мин"), buttons.MessageButton("🔥 50 мин"))
        .add(buttons.MessageButton("⚡ 15 мин")),
    )


# Фильтр передаем как позиционный аргумент
@focus_router.on_message(has("мин"))
async def handle_focus_duration(message: Message, cursor: FSMCursor):
    duration_text = message.content
    duration_map = {"🍅 25 мин": 25, "🔥 50 мин": 50, "⚡ 15 мин": 15}

    duration = duration_map.get(duration_text, 25)
    user_id = message.sender.user_id

    # Создаем сессию фокуса
    session = FocusSession(user_id, duration)
    focus_storage.add_session(session)

    cursor.change_state(FocusState.WORKING)
    cursor.change_data(
        {
            "focus_start": datetime.now().isoformat(),
            "duration": duration,
            "session_id": session.id,
            "pomodoros_completed": 0,
        }
    )

    end_time = datetime.now() + timedelta(minutes=duration)

    await message.reply(
        f"⏰ **Фокус-сессия началась!**\n\n"
        f"Продолжительность: {duration} минут\n"
        f"Время окончания: {end_time.strftime('%H:%M')}\n\n"
        "🚫 Отключите уведомления\n"
        "💧 Поставьте воду рядом\n"
        "📵 Уберите отвлекающие факторы\n\n"
        "**Удачи в работе!** 💪"
    )

    # Запускаем таймер
    asyncio.create_task(focus_timer(user_id, duration, session.id, message.bot))


async def focus_timer(user_id: int, duration: int, session_id: str, bot):
    await asyncio.sleep(duration * 60)

    # Помечаем сессию как завершенную
    session = focus_storage.sessions.get(session_id)
    if session:
        session.completed = True

    await bot.send_message(
        text=f"✅ **Фокус-сессия завершена!**\n\n"
        f"Отличная работа! {duration} минут продуктивной работы позади.\n\n"
        "Сделайте перерыв:\n"
        "• 🚶 Пройдитесь 5 минут\n"
        "• 💧 Выпейте воды\n"
        "• 🧘 Сделайте разминку",
        user_id=user_id,
        keyboard=buttons.KeyboardBuilder().add(
            buttons.MessageButton("🔄 Новая сессия"),
            buttons.MessageButton("📊 Статистика"),
        ),
    )
